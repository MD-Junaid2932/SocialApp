package com.junaid.social

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Reply
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckBoxOutlineBlank
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Image as ImageIcon
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---- Colors (sampled from the reference screenshot) ----
private val PageBg = Color(0xFFF7FAFF)
private val Blue = Color(0xFF1F5FE0)
private val BlueText = Color(0xFF2457D6)
private val BodyBlue = Color(0xFF1F3FA8)
private val Muted = Color(0xFF8FA3CC)
private val CardBorder = Color(0xFFE1EAF8)
private val ChipBg = Color(0xFFFFFFFF)
private val SoftBlue = Color(0xFFEAF2FF)
private val Heart = Color(0xFFFF3B5C)
private val Badge = Color(0xFFFFA726)

// Reference screenshot is 852px wide and is treated as a 360dp-wide screen.
// Every measurement below is written in screenshot pixels and scaled to the real width.
private const val REF_PX_PER_DP = 852f / 360f
private val LocalU = compositionLocalOf { 1f }

@Composable
private fun dp(px: Number): Dp = (px.toFloat() / REF_PX_PER_DP * LocalU.current).dp

@Composable
private fun sp(px: Number): TextUnit = (px.toFloat() / REF_PX_PER_DP * LocalU.current).sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val u = LocalConfiguration.current.screenWidthDp / 360f
            val d = LocalDensity.current
            CompositionLocalProvider(
                LocalU provides u,
                LocalDensity provides Density(d.density, fontScale = 1f)
            ) {
                SocialScreen()
            }
        }
    }
}

@Composable
private fun SocialScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBg)
            .verticalScroll(rememberScrollState())
    ) {
        Header()
        Spacer(Modifier.height(dp(8)))
        StoriesRow()
        Spacer(Modifier.height(dp(14)))
        FilterChips()
        Spacer(Modifier.height(dp(21)))
        Composer()
        Spacer(Modifier.height(dp(22)))
        PostOne()
        Spacer(Modifier.height(dp(18)))
        PostTwo()
        Spacer(Modifier.height(dp(17)))
        PollCard()
        Spacer(Modifier.height(dp(24)))
    }
}

// ---------------------------------------------------------------- Header
@Composable
private fun Header() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(dp(92))
            .padding(horizontal = dp(20))
    ) {
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = null,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(dp(76))
        )
        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = dp(95))
        ) {
            Text(
                "Social",
                color = Blue,
                fontSize = sp(42),
                fontWeight = FontWeight.Bold,
                lineHeight = sp(44)
            )
            Text(
                "Connect  •  Share  •  Grow",
                color = Color(0xFF8FB0EA),
                fontSize = sp(22),
                fontWeight = FontWeight.Medium,
                lineHeight = sp(24)
            )
        }
        Icon(
            Icons.Outlined.Search, null, tint = Blue,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = dp(560))
                .size(dp(46))
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset(x = dp(636))
        ) {
            Icon(Icons.Outlined.Notifications, null, tint = Blue, modifier = Modifier.size(dp(46)))
            Box(
                Modifier
                    .offset(x = dp(28), y = dp(2))
                    .size(dp(15))
                    .clip(CircleShape)
                    .background(Color(0xFFFF4D6D))
            )
        }
        AvatarWithBadge(
            R.drawable.av_me,
            size = 70,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = dp(721))
        )
    }
}

@Composable
private fun AvatarWithBadge(res: Int, size: Int, modifier: Modifier = Modifier) {
    Box(modifier.size(dp(size))) {
        Image(
            painterResource(res), null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(dp(size))
                .clip(CircleShape)
                .border(BorderStroke(dp(2), Color.White), CircleShape)
        )
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .offset(x = dp(2), y = dp(2))
                .size(dp(24))
                .clip(CircleShape)
                .background(Badge)
                .border(BorderStroke(dp(2), Color.White), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(dp(16)))
        }
    }
}

// ---------------------------------------------------------------- Stories
@Composable
private fun StoriesRow() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(dp(170))
    ) {
        // Create story card
        Column(
            Modifier
                .offset(x = dp(20))
                .width(dp(126))
                .height(dp(170))
                .clip(RoundedCornerShape(dp(30)))
                .background(Color(0xFFF1F6FF))
                .border(BorderStroke(dp(1), Color(0xFFE7EFFC)), RoundedCornerShape(dp(30))),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(dp(8)))
            Box(
                Modifier
                    .size(dp(102))
                    .clip(CircleShape)
                    .background(Color(0xFFE3EDFF)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Add, null, tint = Blue, modifier = Modifier.size(dp(54)))
            }
            Spacer(Modifier.height(dp(8)))
            Text(
                "Create\nStory",
                color = BlueText,
                fontSize = sp(21),
                fontWeight = FontWeight.SemiBold,
                lineHeight = sp(25),
                textAlign = TextAlign.Center
            )
        }
        val stories = listOf(
            Triple("Md. Arif", R.drawable.av_arif, 232),
            Triple("Nusrat", R.drawable.av_nusrat, 369),
            Triple("Jannat", R.drawable.av_jannat, 507),
            Triple("Mim", R.drawable.av_mim, 641),
            Triple("Rafi", R.drawable.av_rafi, 773)
        )
        stories.forEach { (name, res, cx) ->
            Column(
                Modifier
                    .offset(x = dp(cx - 60))
                    .width(dp(120))
                    .height(dp(170)),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(dp(8)))
                Image(
                    painterResource(res), null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(dp(106))
                        .clip(CircleShape)
                        .border(BorderStroke(dp(2), Color.White), CircleShape)
                )
                Spacer(Modifier.height(dp(14)))
                Text(
                    name,
                    color = BlueText,
                    fontSize = sp(21),
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Filter chips
@Composable
private fun FilterChips() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(dp(66))
    ) {
        Chip("All", Icons.Outlined.GridView, x = 21, w = 128, selected = true)
        Chip("Following", Icons.Outlined.Group, x = 161, w = 182)
        Chip("Text", Icons.Outlined.Article, x = 355, w = 123)
        Chip("Image", Icons.Outlined.ImageIcon, x = 490, w = 139)
        Chip("Poll", Icons.Outlined.BarChart, x = 641, w = 116)
        Chip(null, Icons.Outlined.Tune, x = 768, w = 63)
    }
}

@Composable
private fun Chip(
    label: String?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    x: Int,
    w: Int,
    selected: Boolean = false
) {
    val shape = RoundedCornerShape(dp(18))
    Row(
        Modifier
            .offset(x = dp(x))
            .width(dp(w))
            .height(dp(65))
            .clip(shape)
            .background(if (selected) Blue else ChipBg)
            .border(BorderStroke(dp(1), if (selected) Blue else CardBorder), shape),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            icon, null,
            tint = if (selected) Color.White else BlueText,
            modifier = Modifier.size(dp(36))
        )
        if (label != null) {
            Spacer(Modifier.width(dp(10)))
            Text(
                label,
                color = if (selected) Color.White else BlueText,
                fontSize = sp(23),
                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

// ---------------------------------------------------------------- Composer
@Composable
private fun Composer() {
    val shape = RoundedCornerShape(dp(26))
    Row(
        Modifier
            .padding(horizontal = dp(20))
            .fillMaxWidth()
            .height(dp(98))
            .clip(shape)
            .background(Color.White)
            .border(BorderStroke(dp(1), CardBorder), shape),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(dp(18)))
        AvatarWithBadge(R.drawable.av_rakib, size = 76)
        Spacer(Modifier.width(dp(23)))
        Box(
            Modifier
                .width(dp(448))
                .height(dp(65))
                .clip(RoundedCornerShape(dp(33)))
                .background(Color(0xFFF1F6FF))
                .border(BorderStroke(dp(1), Color(0xFFE3ECFB)), RoundedCornerShape(dp(33))),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                "What’s on your mind?",
                color = Color(0xFF9DB2DC),
                fontSize = sp(24),
                modifier = Modifier.padding(start = dp(23))
            )
        }
        Spacer(Modifier.width(dp(24)))
        Icon(Icons.Outlined.ImageIcon, null, tint = Blue, modifier = Modifier.size(dp(40)))
        Spacer(Modifier.width(dp(38)))
        Icon(Icons.Outlined.BarChart, null, tint = Blue, modifier = Modifier.size(dp(40)))
        Spacer(Modifier.width(dp(36)))
        Icon(Icons.Outlined.Edit, null, tint = Blue, modifier = Modifier.size(dp(38)))
    }
}

// ---------------------------------------------------------------- Posts
@Composable
private fun PostCard(height: Int, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(dp(26))
    Column(
        Modifier
            .padding(horizontal = dp(20))
            .fillMaxWidth()
            .height(dp(height))
            .clip(shape)
            .background(Color.White)
            .border(BorderStroke(dp(1), CardBorder), shape)
    ) { content() }
}

@Composable
private fun PostHeader(
    avatar: Int,
    name: String,
    time: String,
    verified: Boolean,
    tag: String?,
    tagIcon: Boolean = false
) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(dp(80))
            .padding(horizontal = dp(22))
    ) {
        Image(
            painterResource(avatar), null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(dp(80))
                .clip(CircleShape)
        )
        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = dp(108))
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    name,
                    color = BlueText,
                    fontSize = sp(26),
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip
                )
                if (verified) {
                    Spacer(Modifier.width(dp(8)))
                    Icon(Icons.Filled.Verified, null, tint = Blue, modifier = Modifier.size(dp(26)))
                }
                if (tag != null) {
                    Spacer(Modifier.width(dp(16)))
                    Row(
                        Modifier
                            .height(dp(31))
                            .clip(RoundedCornerShape(dp(16)))
                            .background(Color(0xFFE6EFFF))
                            .padding(horizontal = dp(if (tagIcon) 14 else 18)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (tagIcon) {
                            Icon(
                                Icons.Filled.Verified, null, tint = Blue,
                                modifier = Modifier.size(dp(19))
                            )
                            Spacer(Modifier.width(dp(8)))
                        }
                        Text(
                            tag,
                            color = Blue,
                            fontSize = sp(19),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            Spacer(Modifier.height(dp(6)))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(time, color = Muted, fontSize = sp(21))
                Text("  •  ", color = Muted, fontSize = sp(21))
                Text("Public", color = Muted, fontSize = sp(21))
                Spacer(Modifier.width(dp(8)))
                Icon(Icons.Outlined.Public, null, tint = Muted, modifier = Modifier.size(dp(22)))
            }
        }
        Icon(
            Icons.Filled.MoreHoriz, null, tint = Blue,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(y = dp(8))
                .size(dp(36))
        )
    }
}

@Composable
private fun ActionRow(likes: String, comments: String, shares: String, bookmarkX: Int = 0) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(dp(50))
            .padding(horizontal = dp(22))
    ) {
        Row(
            Modifier.align(Alignment.CenterStart),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Favorite, null, tint = Heart, modifier = Modifier.size(dp(44)))
            Spacer(Modifier.width(dp(12)))
            Text(likes, color = BlueText, fontSize = sp(23), fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(dp(54)))
            Icon(Icons.Outlined.ChatBubbleOutline, null, tint = Blue, modifier = Modifier.size(dp(38)))
            Spacer(Modifier.width(dp(14)))
            Text(comments, color = BlueText, fontSize = sp(23), fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(dp(60)))
            Icon(
                Icons.AutoMirrored.Outlined.Reply, null, tint = Blue,
                modifier = Modifier
                    .size(dp(42))
                    .graphicsLayer(scaleX = -1f)
            )
            Spacer(Modifier.width(dp(14)))
            Text(shares, color = BlueText, fontSize = sp(23), fontWeight = FontWeight.Bold)
        }
        Icon(
            Icons.Outlined.BookmarkBorder, null, tint = Blue,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .size(dp(42))
        )
    }
}

private val bodyStyle
    @Composable get() = TextStyle(
        color = BodyBlue,
        fontSize = sp(27),
        lineHeight = sp(39),
        fontWeight = FontWeight.Medium
    )

@Composable
private fun PostOne() {
    PostCard(height = 602) {
        Spacer(Modifier.height(dp(17)))
        PostHeader(R.drawable.av_rakib, "Rakib Hasan", "2 hours ago", verified = true, tag = "My Post")
        Spacer(Modifier.height(dp(12)))
        Text(
            "জীবনের প্রতিটি মুহূর্তই একটা নতুন পর্ব\n" +
                "সেই পর্বে দাঁড়ালে তহ হয় মুশাম, আর সেই না পারলে তা হয়\n" +
                "শুধু তুমি হয়ে বাস! ✨",
            style = bodyStyle,
            modifier = Modifier.padding(horizontal = dp(22))
        )
        Spacer(Modifier.height(dp(7)))
        Image(
            painterResource(R.drawable.post_img1), null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .padding(horizontal = dp(22))
                .fillMaxWidth()
                .height(dp(288))
                .clip(RoundedCornerShape(dp(14)))
        )
        Spacer(Modifier.height(dp(18)))
        ActionRow("342", "48", "22")
    }
}

@Composable
private fun PostTwo() {
    PostCard(height = 457) {
        Spacer(Modifier.height(dp(19)))
        PostHeader(R.drawable.av_sadia, "Sadia Islam", "5 hours ago", verified = false, tag = null)
        Spacer(Modifier.height(dp(2)))
        Text(
            "আজ একটা নতুন গল্প লিখতে শুরু করলাম।\n" +
                "কি হবে সেটা জানি না, তবে একটা বেশ ভালো লাগছে! 😊",
            style = bodyStyle.copy(lineHeight = sp(42)),
            modifier = Modifier.padding(horizontal = dp(22))
        )
        Spacer(Modifier.height(dp(8)))
        Image(
            painterResource(R.drawable.post_img2), null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .padding(horizontal = dp(22))
                .fillMaxWidth()
                .height(dp(199))
                .clip(RoundedCornerShape(dp(6)))
        )
        Spacer(Modifier.height(dp(9)))
        ActionRow("198", "35", "12")
    }
}

// ---------------------------------------------------------------- Poll
@Composable
private fun PollCard() {
    PostCard(height = 230) {
        Spacer(Modifier.height(dp(13)))
        PostHeader(
            R.drawable.av_tania, "Tania Akter", "12 hours ago",
            verified = false, tag = "Poll", tagIcon = true
        )
        Text(
            "তোমার সঙ্গে, জীবনের সবচেয়ে গুরুত্বপূর্ণ জিনিস কোনটি?",
            style = bodyStyle.copy(fontSize = sp(26), lineHeight = sp(34)),
            modifier = Modifier.padding(horizontal = dp(26), vertical = dp(2))
        )
        Spacer(Modifier.height(dp(6)))
        Box(
            Modifier
                .padding(horizontal = dp(26))
                .fillMaxWidth()
                .height(dp(70))
                .clip(RoundedCornerShape(dp(16)))
                .background(SoftBlue)
                .border(BorderStroke(dp(1), Color(0xFFD9E6FB)), RoundedCornerShape(dp(16)))
        ) {
            Icon(
                Icons.Outlined.CheckBoxOutlineBlank, null, tint = BodyBlue,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = dp(30))
                    .size(dp(40))
            )
            Text(
                "জান / পরিবার",
                color = BodyBlue,
                fontSize = sp(21),
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = dp(100), y = dp(10))
            )
            Text(
                "342 votes",
                color = Muted,
                fontSize = sp(21),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = dp(572), y = dp(10))
            )
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = dp(100), y = dp(38))
                    .width(dp(468))
                    .height(dp(11))
                    .clip(RoundedCornerShape(dp(6)))
                    .background(Color(0xFFCFE0FB))
            ) {
                Box(
                    Modifier
                        .width(dp(235))
                        .height(dp(11))
                        .clip(RoundedCornerShape(dp(6)))
                        .background(Blue)
                )
            }
            Text(
                "42%",
                color = Blue,
                fontSize = sp(26),
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = dp(16))
            )
        }
    }
}
